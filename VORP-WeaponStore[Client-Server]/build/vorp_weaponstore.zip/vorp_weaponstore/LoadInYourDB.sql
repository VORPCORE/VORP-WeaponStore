INSERT INTO `items` (`item`, `label`, `limit`, `can_remove`, `type`, `usable`) VALUES
('ammo_bullet_pistol', 'Munición de Pistola', 10, 1, 'item_standard', 1),
('ammo_bullet_revolver', 'Munición de Revolver', 10, 1, 'item_standard', 1),
('ammo_bullet_rifle', 'Munición de Rifle', 1, 1, 'item_standard', 1),
('ammo_bullet_varmint', 'Munición de Varmint', 1, 1, 'item_standard', 1),
('ammo_shotgun', 'Munición de Escopeta', 10, 1, 'item_standard', 1),
('ammo_bullet_repeater', 'Munición de Repetición', 10, 1, 'item_standard', 1);